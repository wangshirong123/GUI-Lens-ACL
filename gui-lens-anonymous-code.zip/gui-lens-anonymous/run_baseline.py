"""Portable reproduction scheduler. Run --check first; model calls require --run."""
import argparse,concurrent.futures,getpass,hashlib,importlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
import psutil
ROOT=Path(__file__).resolve().parent
METHODS={"direct":"direct_method","adazoom":"adazoom_core","bami":"bami_deepseek","zoomclick":"zoomclick_deepseek"}
def read(p):return json.loads(Path(p).read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load_method(name):
    sys.path[:0]=[str(ROOT/"comparisons"/name),str(ROOT/"comparisons/common"),str(ROOT)]
    return importlib.import_module(METHODS[name])
def sample_set(args):
    manifest=read(ROOT/"comparisons"/args.method/"sample_manifest.json")
    data=read(args.data_dir/"annotations/all.json")
    byid={s["id"]:s for s in data}
    if len(byid)!=len(data) or set(byid)!=set(manifest["sample_ids"]):raise RuntimeError("Dataset IDs differ from the evaluation")
    return [byid[sid] for sid in manifest["sample_ids"]][:args.limit or None],manifest
def resource_check(out):
    if psutil.virtual_memory().available<1.5*2**30 or shutil.disk_usage(out).free<2*2**30:raise RuntimeError("Insufficient RAM/disk")
    if (out/"STOP").exists():raise RuntimeError("STOP requested")
def checkpoints(folder):
    return [p for p in folder.glob("*.json") if p.name not in ("result.json","failure.json","process.json")]
def finished_network(folder):
    bad=[]
    for p in checkpoints(folder):
        r=read(p)
        if r.get("status")=="inflight":return []
        if r.get("error"):
            # No successful answer is ever archived or repeated.
            if r.get("status")!="finished" or r["error"].get("category")!="provider_transport":return []
            if any(a.get("http_status")==200 for a in r.get("attempts",[])):return []
            bad.append(p)
    return bad
def child(args):
    data,manifest=sample_set(args);s=next(s for s in data if s["id"]==args.child)
    folder=args.output_dir/"samples"/s["id"];folder.mkdir(parents=True,exist_ok=True)
    if (folder/"result.json").exists():return
    resource_check(args.output_dir)
    if sha(args.data_dir/"images"/(s["id"]+".png"))!=manifest["images"][s["id"]]:raise RuntimeError("Image hash changed")
    m=load_method(args.method)
    public={k:s[k] for k in ("id","instruction","img_size")}
    rec=m.predict(public,folder);err=rec.get("error")
    import experiment_io as c
    if err and err.get("category")!="model_parse":
        c.save(folder/"failure.json",{"sample_id":s["id"],"error":err});return
    c.save(folder/"result.json",m.score(rec,s))
def worker(args,sample):
    resource_check(args.output_dir)
    folder=args.output_dir/"samples"/sample["id"];folder.mkdir(parents=True,exist_ok=True)
    cmd=[sys.executable,"-X","utf8","-B",str(Path(__file__)),"--method",args.method,"--data-dir",str(args.data_dir),
         "--output-dir",str(args.output_dir),"--child",sample["id"]]
    with (folder/"worker.log").open("ab") as log:
        proc=subprocess.Popen(cmd,stdout=log,stderr=log,stdin=subprocess.DEVNULL,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        owner=psutil.Process(proc.pid);created=owner.create_time()
        try:proc.wait(timeout=1500)
        except subprocess.TimeoutExpired:
            if owner.is_running() and abs(owner.create_time()-created)<.01:
                children=owner.children(recursive=True)
                for p in children+[owner]:
                    try:p.terminate()
                    except psutil.NoSuchProcess:pass
                psutil.wait_procs(children+[owner],timeout=5)
            raise RuntimeError("Worker timed out; preserve checkpoints and inspect before replay")
    if (folder/"result.json").exists():return True
    if not finished_network(folder):raise RuntimeError("Unresolved worker failure: "+sample["id"]+"; inspect local worker.log")
    return False
def run_phase(args,samples,worker_fn=None):
    # Keep only active slots submitted, so a global failure cannot dispatch
    # the remainder of the dataset while the executor is shutting down.
    worker_fn=worker_fn or worker
    pending=iter(samples);deferred=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        active={}
        def submit_next():
            sample=next(pending,None)
            if sample is not None:active[pool.submit(worker_fn,args,sample)]=sample
        for _ in range(args.workers):submit_next()
        try:
            while active:
                done,_=concurrent.futures.wait(active,return_when=concurrent.futures.FIRST_COMPLETED)
                for future in done:
                    sample=active.pop(future)
                    if not future.result():deferred.append(sample)
                for _ in done:submit_next()
        except BaseException:
            for future in active:future.cancel()
            raise
    return deferred
def package_signature():
    # Avoid using old results with changed packaged code.
    paths=[ROOT/"run_baseline.py"]+list((ROOT/"comparisons").rglob("*.py"))
    return hashlib.sha256("".join(p.relative_to(ROOT).as_posix()+sha(p) for p in sorted(paths)).encode()).hexdigest()
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--method",choices=METHODS,required=True)
    p.add_argument("--data-dir",type=Path,required=True)
    p.add_argument("--output-dir",type=Path,default=Path("runs/baseline"))
    p.add_argument("--limit",type=int,default=0)
    p.add_argument("--workers",type=int,choices=range(1,5),default=4)
    p.add_argument("--check",action="store_true")
    p.add_argument("--run",action="store_true")
    p.add_argument("--resume",action="store_true")
    p.add_argument("--retry-network",action="store_true",help="Authorize finished transport failures to be deferred and retried, at most 2/sample and 20/run; server outcome/cost may be unknown.")
    p.add_argument("--prompt-key",action="store_true")
    p.add_argument("--child")
    a=p.parse_args();a.data_dir=a.data_dir.resolve();a.output_dir=a.output_dir.resolve()
    os.environ["GUI_LENS_DATA_DIR"]=str(a.data_dir);os.environ["GUI_LENS_OUTPUT_DIR"]=str(a.output_dir)
    data,manifest=sample_set(a)
    if a.child:child(a);return
    m=load_method(a.method)
    if a.check:
        from PIL import Image
        for s in data:
            f=a.data_dir/"images"/(s["id"]+".png")
            if sha(f)!=manifest["images"][s["id"]]:raise RuntimeError("Image hash mismatch: "+s["id"])
            with Image.open(f) as im:
                if list(im.size)!=s["img_size"]:raise RuntimeError("Image size mismatch")
        print("PASS: imports, IDs, image hashes and dimensions; no API request.");return
    if not a.run:p.error("Choose --check or --run")
    if a.output_dir.exists() and any(a.output_dir.iterdir()) and not a.resume:p.error("Existing output: use --resume")
    a.output_dir.mkdir(parents=True,exist_ok=True)
    # OS lock is released after crashes without deleting other jobs' locks.
    from filelock import FileLock
    with FileLock(str(a.output_dir/"experiment.lock"),timeout=0):
        import experiment_io as c
        resource_check(a.output_dir)
        signature={"method":a.method,"code_sha256":package_signature(),"sample_ids":[s["id"] for s in data]}
        config=a.output_dir/"run_manifest.json"
        if config.exists():
            if read(config)!=signature:raise RuntimeError("Run configuration changed")
        else:c.save(config,signature)
        if a.prompt_key and not os.environ.get("DEEPSEEK_API_KEY"):
            os.environ["DEEPSEEK_API_KEY"]=getpass.getpass("DeepSeek API key (hidden, not saved): ").strip()
        import deepseek_transport as t
        t.key()
        # Check model identity once before any paid inference.
        expected={"id":"deepseek-flash","name":"DeepSeek-V4.1-Flash","input_modalities":["text","image"]}
        t.metadata(a.output_dir,c,expected)
        pending=[s for s in data if not (a.output_dir/"samples"/s["id"]/"result.json").exists()]
        runnable=[];deferred=[]
        for s in pending:
            folder=a.output_dir/"samples"/s["id"]
            if finished_network(folder):deferred.append(s)
            else:runnable.append(s)
        deferred.extend(run_phase(a,runnable))
        # Fixed budget; explicit finished failures only. No unknown inflight replay.
        while deferred and a.retry_network:
            ready=[];left=[]
            for s in deferred:
                folder=a.output_dir/"samples"/s["id"];bad=finished_network(folder)
                own=len(list((folder/"failed_attempts").glob("attempt_*")))
                total=len(list((a.output_dir/"samples").glob("*/failed_attempts/attempt_*")))
                if not bad or own>=2 or total>=20:left.append(s);continue
                resource_check(a.output_dir);time.sleep(60);resource_check(a.output_dir)
                before=sorted((p.name,sha(p)) for p in checkpoints(folder))
                dest=folder/"failed_attempts"/("attempt_%02d"%(own+1));dest.mkdir(parents=True,exist_ok=False)
                for f in bad:f.rename(dest/f.name)
                after=sorted((p.name,sha(p)) for p in checkpoints(folder))+[(p.name,sha(p)) for p in dest.glob("*.json")]
                if sorted(after)!=before:raise RuntimeError("Sample checkpoint archive changed")
                c.save(dest/"recovery.json",{"unknown_usage_retained":True,"authorized":True,"time":c.now()})
                ready.append(s)
            if not ready:deferred=left;break
            left.extend(run_phase(a,ready))
            deferred=left
        results=[read(a.output_dir/"samples"/s["id"]/"result.json") for s in data if (a.output_dir/"samples"/s["id"]/"result.json").exists()]
        (a.output_dir/"results.jsonl").write_text("".join(json.dumps(r,ensure_ascii=False)+"\n" for r in results),encoding="utf-8")
        c.save(a.output_dir/"deferred.json",{"sample_ids":[s["id"] for s in deferred]})
        print(json.dumps({"completed":len(results),"target":len(data),"deferred":len(deferred),"status":"complete" if len(results)==len(data) else "incomplete"},indent=2))
if __name__=="__main__":main()
