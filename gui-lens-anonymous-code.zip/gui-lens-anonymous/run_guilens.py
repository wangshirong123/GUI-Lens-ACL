"""Portable packaging entry; delegates inference and scoring to unchanged source."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys

ROOT = Path(__file__).resolve().parent

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    ap = argparse.ArgumentParser(description='GUI-Lens grounding evaluator')
    ap.add_argument('--data-dir', type=Path, required=True, help='Contains annotations/all.json and images/<sample_id>.png')
    ap.add_argument('--assets-dir', type=Path, required=True, help='Contains gpa/model.pt and easyocr/model/*.pth')
    ap.add_argument('--output-dir', type=Path, required=True, help='Use a new, independent experiment directory')
    ap.add_argument('--indexes', default='0-4', help='Zero-based annotation indexes, e.g. 0-4 or 1,3,5')
    ap.add_argument('--all', action='store_true', help='Select all 1581 samples')
    ap.add_argument('--resume', action='store_true', help='Skip every sample already present in results.jsonl, including errors')
    ap.add_argument('--dry-run', action='store_true', help='Validate files and print arguments; no model imports or calls')
    ap.add_argument('--provider', required=True)
    ap.add_argument('--model', required=True)
    ap.add_argument('--config', type=Path, required=True)
    args = ap.parse_args()
    data = args.data_dir.resolve()
    assets = args.assets_dir.resolve()
    output = args.output_dir.resolve()
    config = args.config.resolve()
    if not config.is_file(): raise SystemExit("Missing configuration")
    ann = data/"annotations/all.json"
    samples = json.loads(ann.read_text(encoding='utf-8-sig'))
    if len(samples)!=1581 or len({s['id'] for s in samples})!=1581:
        raise SystemExit('Expected 1581 unique samples')
    selected = set()
    for part in ('0-1580' if args.all else args.indexes).split(','):
        bounds = part.strip().split('-')
        if len(bounds)==1:
            selected.add(int(bounds[0]))
        elif len(bounds)==2:
            lo, hi = map(int,bounds)
            if lo>hi: raise SystemExit('Descending index range')
            selected.update(range(lo,hi+1))
        else:
            raise SystemExit('Invalid indexes')
    if not selected or min(selected)<0 or max(selected)>=len(samples):
        raise SystemExit('Indexes outside annotation range')
    for i in selected:
        image = data/'images'/(samples[i]['id']+'.png')
        if not image.is_file(): raise SystemExit('Missing image: '+str(image))
    for name in ['gpa/model.pt','easyocr/model/craft_mlt_25k.pth','easyocr/model/zh_sim_g2.pth']:
        if not (assets/name).is_file(): raise SystemExit('Missing asset: '+str(assets/name))
    if output.exists() and any(output.iterdir()) and not args.resume:
        raise SystemExit('Output directory is nonempty; use a new directory or explicit --resume')
    runner = ROOT/'benchmarks/screenspot_pro/run_screenspot_pro.py'
    argv = [str(runner),'--data-dir',str(data),'--annotation','all.json',
            '--indexes',','.join(map(str,sorted(selected))),
            '--provider',args.provider,'--model',args.model,
            '--config',str(config),'--output',str(output/'results.jsonl'),
            '--work-dir',str(output/'work'),'--exec-timeout-s','180',
            '--runtime-retries','1','--retry-provider-errors','1']
    if args.resume: argv.append('--skip-existing')
    print(json.dumps({'selected':len(selected),'dry_run':args.dry_run,'command':argv},ensure_ascii=False,indent=2))
    if args.dry_run: return
    output.mkdir(parents=True,exist_ok=True)
    for env, rel in {'TEMP':'tmp','TMP':'tmp','TORCH_HOME':'cache/torch',
                     'HF_HOME':'cache/huggingface','YOLO_CONFIG_DIR':'cache/ultralytics',
                     'MPLCONFIGDIR':'cache/matplotlib'}.items():
        target = output/rel
        target.mkdir(parents=True,exist_ok=True)
        os.environ[env] = str(target)
    os.environ['EASYOCR_MODULE_PATH'] = str(assets/'easyocr')
    os.environ['GPA_MODEL_PATH'] = str(assets/'gpa/model.pt')
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    os.environ['OPENPROGRAM_EXEC_TIMEOUT_S'] = '180'
    os.environ['OPENPROGRAM_DEBUG_PROVIDER'] = '0'
    os.environ['GUI_HARNESS_SCREENSPOT_ABORT_ON_PROVIDER_RATE_LIMIT'] = '1'
    sys.dont_write_bytecode = True
    # Match the historical Windows entry: enable Unicode-safe OpenCV I/O first.
    import ultralytics
    sys.path[:0] = [str(ROOT), str(ROOT/'vendor/OpenProgram')]
    sys.argv = argv
    runpy.run_path(str(runner),run_name='__main__')

if __name__ == '__main__':
    main()
