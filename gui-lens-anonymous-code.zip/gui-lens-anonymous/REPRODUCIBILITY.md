# Reproduction guide and coverage

## Environment

Baseline evaluation: Python 3.11 and environment/requirements-baselines.txt.

Preserved GUI-Lens Windows environment: PyTorch 2.5.1+cu121, torchvision 0.20.1+cu121,
NumPy 1.26.4, OpenCV 4.11.0.86, Ultralytics 8.4.75, EasyOCR 1.7.2.
The full original package list is environment/requirements-reference.txt.
It is a Windows installation record, not a guarantee of portability to every OS/GPU.
Choose a compatible PyTorch build for other systems.

    python -m pip install -r environment/requirements-reference.txt --extra-index-url https://download.pytorch.org/whl/cu121
    python -m pip install "setuptools>=68,<75" wheel
    python -m pip install --no-deps --no-build-isolation ./vendor/OpenProgram
    python -m pip install --no-deps -e .

The bundled OpenProgram 0.5.0 snapshot removes author-account links and personal
network/account examples. Online program installation/update and channel/web UI
features are outside this reproduction workflow.

## ScreenSpot-Pro

Official project: https://github.com/likaixin2000/ScreenSpot-Pro-GUI-Grounding

Obtain the official release under its terms. Screenshots/weights are not redistributed.
Normalized layout:

    data/ScreenSpot-Pro/
      annotations/all.json
      images/<sample_id>.png

all.json: 1,581 records including id, instruction, img_size [width,height],
bbox [left,top,right,bottom], group (CAD/Dev/Creative/Scientific/Office/OS),
and ui_type (text/icon). Included sample manifests contain ID order and image hashes.
Preserve original PNG bytes when renaming images.

    python tools/prepare_screenspot.py --source /path/to/official/ScreenSpot-Pro --destination data/ScreenSpot-Pro
    python run_baseline.py --method direct --data-dir data/ScreenSpot-Pro --check

## GUI-Lens assets and execution

Obtain Salesforce/GPA-GUI-Detector and EasyOCR weights from their official
distributions. Expected asset hashes: environment/model_assets.json.

    models/
      gpa/model.pt
      easyocr/model/craft_mlt_25k.pth
      easyocr/model/zh_sim_g2.pth

The launcher configures GPA_MODEL_PATH and EASYOCR_MODULE_PATH.
Use the reproducing researcher's own provider credentials.

    python run_guilens.py --data-dir data/ScreenSpot-Pro --assets-dir models --output-dir runs/gui-lens --provider openai-codex --model gpt-5.5 --config benchmarks/screenspot_pro/configs/legacy_baseline.yaml --all --dry-run

Remove --dry-run only after data, weights and provider setup.
Inference/scoring delegate to the preserved evaluator. --resume skips all saved
results including errors; it does not select a new answer for completed samples.

## Reported results and configuration coverage

The final manuscript reports the following full ScreenSpot-Pro GUI-Lens results.
The authors confirm these are their measured results:

| Backbone | Accuracy (%) |
|---|---:|
| MiniMax-M3 | 47.4 |
| DeepSeek-V4.1-Flash | 72.9 |
| Claude Opus 4.7 | 82.3 |
| GPT-5.5 | 87.9 |

The paper's component ablations use a separate, shared 300-example subset.
These subset results must not be substituted for the full benchmark rows.
Earlier repository notes refer to historical subset experiments and are not the
source of the final paper's full-set labels.

This code release contains the main grounding implementation and preserved
configuration variants, including legacy_baseline.yaml, sspro_stack_zoom.yaml,
sspro_stack_zoom_claude2000.yaml, m3_optimal.yaml and component ablations. Select
the configuration for the experiment being reproduced; the different files are
not interchangeable. The exact final per-run configuration mapping and the
main-method per-example output records are not included in the current artifact.
The current package therefore does not independently re-score the four GUI-Lens
rows above or validate their paired significance tests.

The direct/AdaZoom/BAMI/ZoomClick DeepSeek comparisons have complete exported
predictions for all 1,581 examples. Their scores and numeric call ledgers are
independently rechecked by tools/report_results.py. This packaging audit did not
rerun paid inference. Source preservation, author-reported scores, and independent
result verification are distinct forms of evidence.

## Other benchmarks

- UI-Vision and MMBench-GUI-L2:
  benchmarks/screenspot_pro/prepare_gui_grounding_datasets.py.
- ScreenSpot versions:
  benchmarks/screenspot_pro/data_prep/prepare_screenspot_versions.py.
- Additional data/report utilities: data_prep/ and reporting/ in that directory.
- OSWorld: benchmarks/osworld/run_osworld_task.py and eval_osworld_task.py.
  Install official OSWorld separately and supply an explicit run-config/VM path.
  Virtual machines, tasks and external evaluator dependencies are not bundled.
  These entries operate a VM and were not run end to end during packaging.

Reporting utilities require corresponding experiment outputs. Private run
directories and account-specific historical launchers are excluded.

## Validation

    python tools/report_results.py
    python -m unittest discover -s tests -p "test_review_package.py"

The audit checks unique IDs, every exported point against its original bbox,
and numeric usage sums across all attempts. Missing usage remains null.
For the additional ZoomClick algorithm/checkpoint test, first run
python tools/fetch_zoomclick.py. Network is needed to retrieve public source,
but no model request is made. Packaging tests used locally preserved files whose
hashes match the pinned revision. No fresh paid benchmark run was performed.
