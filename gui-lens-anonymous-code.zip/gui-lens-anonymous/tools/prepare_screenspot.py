"""Normalize official ScreenSpot-Pro files without recompressing images."""
import argparse,hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--source",type=Path,required=True)
    ap.add_argument("--destination",type=Path,required=True)
    ap.add_argument("--check-only",action="store_true")
    args=ap.parse_args();src=args.source.resolve();dst=args.destination.resolve()
    if src==dst:raise SystemExit("Use a different destination; source data are never modified")
    manifest=json.loads((ROOT/"comparisons/direct/sample_manifest.json").read_text())
    ann=src/"annotations";files=[ann/"all.json"] if (ann/"all.json").exists() else sorted(ann.glob("*.json"))
    rows=[]
    for f in files:
        data=json.loads(f.read_text(encoding="utf-8-sig"))
        if not isinstance(data,list):raise ValueError("Expected annotation list: "+f.name)
        rows.extend(data)
    byid={s["id"]:s for s in rows}
    if len(rows)!=len(byid) or set(byid)!=set(manifest["sample_ids"]):raise ValueError("Expected the exact 1581 unique benchmark IDs")
    selected=[]
    for sid in manifest["sample_ids"]:
        s=byid[sid]
        if any(k not in s for k in ("instruction","bbox","img_size","group","ui_type")):raise ValueError("Incomplete annotation: "+sid)
        original=Path(s.get("img_filename",sid+".png"))
        if original.is_absolute() or ".." in original.parts:raise ValueError("Invalid image-relative path")
        candidates=[src/"images"/(sid+".png"),src/"images"/original,src/"raw_images"/original,src/original]
        image=next((p for p in candidates if p.is_file()),None)
        if image is None:raise FileNotFoundError("Missing image: "+sid)
        selected.append((s,image))
    if args.check_only:print("PASS: 1581 annotations and source image paths; no files written");return
    if dst.exists() and any(dst.iterdir()):raise ValueError("Destination must be empty")
    (dst/"annotations").mkdir(parents=True,exist_ok=True);(dst/"images").mkdir()
    for s,image in selected:
        if hashlib.sha256(image.read_bytes()).hexdigest()!=manifest["images"][s["id"]]:raise ValueError("Image bytes differ: "+s["id"])
        shutil.copyfile(image,dst/"images"/(s["id"]+".png"))
    (dst/"annotations/all.json").write_text(json.dumps([s for s,p in selected],ensure_ascii=False,indent=2),encoding="utf-8")
    print("PASS: 1581 normalized records and unchanged image bytes")
if __name__=="__main__":main()
