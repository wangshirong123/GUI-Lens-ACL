"""Independently score exported points and print the paper's 15 accuracy columns."""
import json
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
GROUPS=["CAD","Dev","Creative","Scientific","Office","OS"]
LABELS={"direct":"DeepSeek-V4.1-Flash","adazoom":"AdaZoom-GUI (DeepSeek-V4.1-Flash)","bami":"BAMI (DeepSeek-V4.1-Flash)","zoomclick":"ZoomClick (DeepSeek-V4.1-Flash)"}
def rows(p):return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]
def accuracy(rs):return 100*sum(r["correctness"]=="correct" for r in rs)/len(rs) if rs else 0
def audit(method):
    data=rows(ROOT/"results"/(method+".jsonl"))
    assert len(data)==len({r["sample_id"] for r in data})==1581
    for r in data:
        p=r["prediction_px"];b=r["gt_bbox"]
        expected="wrong_format" if r["error_category"] else ("correct" if p is not None and b[0]<=p[0]<=b[2] and b[1]<=p[1]<=b[3] else "wrong")
        assert expected==r["correctness"],r["sample_id"]
    summary=json.loads((ROOT/"results"/(method+"_summary.json")).read_text())
    assert sum(r["correctness"]=="correct" for r in data)==summary["overall"]["correct"]
    calls=rows(ROOT/"results"/(method+"_calls.jsonl"))
    totals=Counter()
    for c in calls:
        for k,v in (c.get("usage") or {}).items():
            if type(v) in (int,float):totals[k]+=v
    expected_usage=summary["calls"].get("known_usage_totals",summary["calls"].get("known_usage"))
    assert all(totals[k]==v for k,v in expected_usage.items()),(method,totals,expected_usage)
    expected_calls=summary["calls"].get("recorded_attempts",summary["calls"].get("attempts",summary["calls"].get("recorded_runtime_attempts")))
    assert len(calls)==expected_calls
    columns=[accuracy([r for r in data if r["group"]==g and r["ui_type"]==t]) for g in GROUPS for t in ("text","icon")]
    columns += [accuracy([r for r in data if r["ui_type"]==t]) for t in ("text","icon")]+[accuracy(data)]
    return data,calls,columns
def main():
    for method,label in LABELS.items():
        data,calls,columns=audit(method)
        print(label+" & "+" & ".join("%.1f"%x for x in columns)+" "+chr(92)*2)
        print("  verified %d samples; %d attempts; %d unknown-usage records"%(len(data),len(calls),sum(c["usage"] is None for c in calls)))
if __name__=="__main__":main()
