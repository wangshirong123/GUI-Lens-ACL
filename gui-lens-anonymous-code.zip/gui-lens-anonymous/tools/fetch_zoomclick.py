"""Fetch the pinned external ZoomClick source and verify its six SHA-256 hashes."""
import argparse,hashlib,json,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument("--destination",type=Path,default=ROOT/"comparisons/zoomclick/upstream");args=ap.parse_args()
    manifest=json.loads((ROOT/"comparisons/zoomclick/upstream/provenance.json").read_text())
    for name,expected in manifest["files"].items():
        dest=args.destination/name
        if dest.exists() and hashlib.sha256(dest.read_bytes()).hexdigest()==expected:continue
        url="https://raw.githubusercontent.com/Princeton-AI2-Lab/ZoomClick/"+manifest["commit"]+"/"+name
        with urllib.request.urlopen(url,timeout=60) as response:raw=response.read()
        if hashlib.sha256(raw).hexdigest()!=expected:raise RuntimeError("Upstream hash mismatch: "+name)
        dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
        print(name)
    print("PASS: pinned source hashes")
if __name__=="__main__":main()
