"""Verify all tracked files in the anonymous release manifest."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    manifest=json.loads((ROOT/"checksums.json").read_text())
    for rel,expected in manifest.items():
        path=ROOT/rel
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:raise SystemExit("Changed or missing: "+rel)
    print("PASS: %d release file hashes"%len(manifest))
if __name__=="__main__":main()
