# Comparison protocols

Each method independently receives the screenshot and instruction. Prior predictions
and ground truth are excluded from inference. Scoring is inclusive point-in-box in
original-image coordinates, after inference.

## Shared API

Model ID deepseek-flash (recorded name DeepSeek-V4.1-Flash); thinking disabled;
max_tokens 1024; stream false; temperature/top_p omitted. Image detail original
does not disable server preprocessing. System: "You are a helpful assistant."
Four samples may run concurrently; all stages within a sample are serial.
Prompt strings are in the method modules.

## Direct

One full-image PNG and one pixel-JSON point prediction. The original parser
accepts integer-valued floats/strings, rejecting booleans, fractions and points
outside the image.

## AdaZoom-GUI adaptation

Paper: https://arxiv.org/abs/2603.17441v1

Independent implementation with DeepSeek replacing both refiner and grounder,
without training; not the original trained Qwen system.
Instruction refinement precedes grounding. A third call occurs only when the
predicted bbox satisfies (width <= 50 and height <= 100) or its transpose.
The crop has half the original width/height, is shifted inside image boundaries,
and resized to original resolution with LANCZOS. Points map back through actual
crop bounds. Numerical thresholds/zoom ratio are fixed adaptation choices,
not claimed to be official paper defaults.

## BAMI adaptation

Paper: https://arxiv.org/abs/2605.06664
Author repository: https://github.com/Neur-IO/BAMI

Independent point-output interpretation: two rounds, two candidates and one judge
call per round, all using DeepSeek. Candidate two uses a deterministic noisy mask
around candidate one (radius 25). The judge sees two marked versions of a clean
image. After round one, a crop with width/height ratio 0.6 is resized to the
initial resolution using LANCZOS. The original mask seed remains 20261009.
This is an independent adaptation, not an official trained-system reproduction.
Geometry, masking, prompts and transformations are in bami_core.py.

## ZoomClick adaptation

Paper: https://arxiv.org/abs/2512.05941
Code: https://github.com/Princeton-AI2-Lab/ZoomClick
Commit: 6a0c3633eb6985a21d99c94400bc64fe54ac5221.

official_core.py verifies hashes and loads the original named AST definitions.
Depth 3; shrink 0.5; minimum crop 768; patch size 2; center mode clip; prezoom
threshold 50 pixels. The full view and four patches precede up to two refinements
(normally 5–7 calls). Native RGB crops receive no extra manual enlargement.
The DeepSeek adapter uses the direct baseline's pixel-JSON prompt, normalizes
against each supplied view's dimensions and uses official remapping.
Invalid outputs return None to official fallbacks. Stage format errors are
counted separately from final sample format errors.

## Historical recovery accounting

Successful responses were not retried to improve accuracy. All failed attempts
remain in the exported usage ledgers.

| Method | Successful attempts | Failed attempts | Unknown-usage attempts |
|---|---:|---:|---:|
| Direct | 1581 | 2 | 2 |
| AdaZoom-GUI | 4281 | 0 | 0 |
| BAMI | 9334 | 79 | 79 |
| ZoomClick | 10937 | 12 | 12 |

BAMI used explicit additional network-recovery authorizations after the original
20-recovery limit: 58 named samples once each, then one subsequently failed sample
once more, for 79 recoveries total. ZoomClick used 12 of 20 allowed recoveries.
These authorizations did not change prompts, geometry, scoring or saved successful
stages. They are historical facts, not unlimited retry settings in the new launcher.
