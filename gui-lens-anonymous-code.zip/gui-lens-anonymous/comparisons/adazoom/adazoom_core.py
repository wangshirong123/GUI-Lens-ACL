"""AdaZoom-style DeepSeek adaptation; same geometry/prompts as frozen LUNA adaptation."""
import argparse
import contextvars
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import table1_common as c
sys.path.insert(0, str(c.REPO))

REFINE = '''Interpret this one-click task using the attached screenshot. Rewrite the task as a direct instruction identifying the intended visible control. Resolve ambiguous wording and add useful visible labels, appearance or relative location. Preserve the user's intent. Return only the rewritten instruction, without explanation or coordinates.
Screenshot dimensions: {w} by {h} pixels.
Task: {instruction}'''
GROUND = '''Locate the control described below in the attached screenshot. Predict a click point inside the control and its tight rectangular bounding box. Use pixel coordinates in THIS supplied image, whose width is {w} and height is {h}. The top-left is (0,0). Return only JSON with integer fields: {{"x": ..., "y": ..., "bbox": [left, top, right, bottom]}}. The click must satisfy 0 <= x < {w}, 0 <= y < {h}. Box edges must satisfy 0 <= left < right <= {w} and 0 <= top < bottom <= {h}. If no applicable target is visible, return {{"x":0,"y":0,"bbox":[0,0,0,0]}}.
Task: {instruction}'''
CONFIG = {
    'method': 'AdaZoom-GUI adapted to DeepSeek-V4.1-Flash, paper-based independent implementation',
    'paper': 'https://arxiv.org/abs/2603.17441v1',
    'model': 'deepseek-flash', 'provider': 'deepseek-official', 'workers': 1,
    'alpha_px': 50, 'beta_px': 100, 'zoom_factor': 2.0,
    'parameter_provenance': 'Author paper v1 gives the gate equation but does not specify numerical alpha, beta or zoom ratio. These values are adaptation choices fixed before evaluation, not official defaults or tuned on test scores.',
    'gate': '(predicted_width <= alpha and predicted_height <= beta) or (predicted_height <= alpha and predicted_width <= beta)',
    'crop': 'Half-width/half-height crop centred on initial predicted click, shifted inside image boundaries; resize to original W,H using Pillow LANCZOS; map final point by actual crop dimensions.',
    'differences_from_paper': ['Both refiner and trained Qwen grounder replaced by deepseek-flash without training.', 'Independently worded prompts and JSON coordinate schema replace paper prompts and pyautogui syntax.', 'Undisclosed numeric thresholds, zoom factor, boundary handling and resize filter fixed explicitly here.'],
    'api': __import__('deepseek_transport').API_CONFIG, 'refinement_prompt': REFINE, 'grounding_prompt': GROUND,
    'timeout_s': 180, 'runtime_retries': 1, 'provider_error_retries': 0,
    'provider_stream_max_attempts': 1,
    'budget': '2 logical stages normally; 3 only if predicted bbox triggers zoom. One runtime call per stage attempt; supervisor allows at most two additional failed-transport attempts per sample and twenty per experiment; no parse/correctness retry or fallback to a more accurate initial answer.',
    'context': 'Fresh runtime and ContextVars per call; only screenshot, current task and dimensions. No tools, OCR, detector, cross-sample history or GT input.',
    'scoring': 'Inclusive original-pixel GT bbox after all inference. Float mapped final coordinates retained without rounding/clamping.',
    'image_processing': 'Original PNG for first two stages. Only conditional zoom resamples. DeepSeek backend automatic resizing remains enabled as in the pure DeepSeek baseline.',
    'order': 'Reuse BAMI stratified pilot200 IDs in their frozen order, then remaining annotation order. No outcome filtering.',
    'min_available_ram_GiB': 1.5,
}
TRANSIENT = {'provider_transport', 'provider_timeout', 'provider_rate_limit'}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def selection():
    data = c.samples()
    first = [next(s for s in data if s['group'] == g) for g in c.GROUPS]
    used = {s['id'] for s in first}
    return first + [s for s in data if s['id'] not in used]


def preflight():
    from PIL import Image
    data = selection()
    for s in data:
        with Image.open(c.IMAGES / (s['id'] + '.png')) as im:
            if list(im.size) != s['img_size']:
                raise ValueError('Image/annotation size mismatch: ' + s['id'])
    return data


def integer(x):
    if isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x) or int(x) != x:
        raise ValueError('Expected finite integer coordinate')
    return int(x)


def parse_ground(raw, width, height):
    from json_parsing import parse_json
    value = parse_json(raw)
    point = [integer(value['x']), integer(value['y'])]
    box = [integer(x) for x in value['bbox']]
    if len(box) != 4: raise ValueError('Expected four bbox edges')
    if point == [0, 0] and box == [0, 0, 0, 0]:
        return {'point': point, 'bbox': box, 'null_action': True}
    if not (0 <= point[0] < width and 0 <= point[1] < height):
        raise ValueError('Click outside supplied image')
    if not (0 <= box[0] < box[2] <= width and 0 <= box[1] < box[3] <= height):
        raise ValueError('Invalid bbox in supplied image')
    return {'point': point, 'bbox': box, 'null_action': False}


def needs_zoom(box):
    w, h = box[2]-box[0], box[3]-box[1]
    a, b = CONFIG['alpha_px'], CONFIG['beta_px']
    return (w <= a and h <= b) or (h <= a and w <= b)


def crop_bounds(point, size):
    width, height = size
    cw, ch = max(1, math.ceil(width/CONFIG['zoom_factor'])), max(1, math.ceil(height/CONFIG['zoom_factor']))
    left = min(max(0, math.floor(point[0]-cw/2)), width-cw)
    top = min(max(0, math.floor(point[1]-ch/2)), height-ch)
    return [left, top, left+cw, top+ch]


def map_point(point, bounds, size):
    l, t, r, b = bounds
    return [l+point[0]*(r-l)/size[0], t+point[1]*(b-t)/size[1]]



class StageFailure(Exception):
    def __init__(self,error):self.error=error;super().__init__(error.get('message',str(error)))

def stage(name,prompt,image,work,rec):
    import deepseek_transport as transport
    fingerprint=digest({'prompt':prompt,'image_sha256':c.sha(image),'config':CONFIG})
    checkpoint=work/(name+'.json')
    if checkpoint.exists():
        saved=c.read(checkpoint)
        if saved['fingerprint']!=fingerprint:raise RuntimeError('Stage input changed on resume')
        if saved['status']!='finished':raise RuntimeError('Inflight outcome unknown; replay prohibited')
    else:
        # Validate inputs/key before the inflight checkpoint; do not include key or request image in logs.
        transport.key()
        saved={'stage':name,'fingerprint':fingerprint,'prompt':prompt,'image_sha256':c.sha(image),
          'status':'inflight','attempts':[],'started_at':c.now()}
        c.save(checkpoint,saved)
        item={'attempt':1,'started_at':c.now(),**transport.request_once(prompt,image)}
        item['finished_at']=c.now()
        saved.update(status='finished',finished_at=item['finished_at'],attempts=[item],error=item.get('error'))
        c.save(checkpoint,saved)  # Preserve every HTTP response before interpreting it.
    rec['stages'].append(saved)
    if saved.get('error'):raise StageFailure(saved['error'])
    item=saved['attempts'][0]
    try:
        response=item['response'];choice=response['choices'][0]
        if choice.get('finish_reason')!='stop':raise ValueError('Incomplete response finish_reason')
        raw=choice['message'].get('content')
        if not isinstance(raw,str):raise ValueError('No text response')
    except (KeyError,IndexError,TypeError) as exc:raise ValueError('Invalid HTTP response body') from exc
    return raw

def predict(public, work):
    """Receives only ID, instruction and dimensions. It has no GT access."""
    from PIL import Image
    sid = public['id']; width, height = public['img_size']
    image = c.IMAGES / (sid+'.png'); start=time.monotonic()
    rec = {'sample_id':sid,'model':CONFIG['model'],'provider':CONFIG['provider'],'stages':[],
           'prediction_px':None,'zoom_triggered':False,'null_action':False,'error':None,'started_at':c.now()}
    try:
        refinement = stage('refine',REFINE.format(w=width,h=height,instruction=public['instruction']),image,work,rec).strip()
        if not refinement: raise ValueError('Empty refined instruction')
        rec['refined_instruction'] = refinement
        prompt = GROUND.format(w=width,h=height,instruction=refinement)
        initial = parse_ground(stage('ground_initial',prompt,image,work,rec),width,height)
        rec['initial_prediction'] = initial
        if initial['null_action']:
            rec['null_action'] = True
        elif not needs_zoom(initial['bbox']):
            rec['prediction_px'] = initial['point']
        else:
            rec['zoom_triggered'] = True
            bounds = crop_bounds(initial['point'],[width,height]); rec['crop_bounds_px'] = bounds
            zoom_image = work/'zoom.png'
            if not zoom_image.exists():
                with Image.open(image) as original:
                    cropped = original.crop(tuple(bounds))
                    resized = cropped.resize((width,height),Image.Resampling.LANCZOS)
                    resized.save(zoom_image,'PNG'); resized.close(); cropped.close()
            zoomed = parse_ground(stage('ground_zoom',prompt,zoom_image,work,rec),width,height)
            rec['zoom_prediction'] = zoomed
            if zoomed['null_action']: rec['null_action'] = True
            else: rec['prediction_px'] = map_point(zoomed['point'],bounds,[width,height])
    except StageFailure as exc: rec['error'] = exc.error
    except (ValueError, KeyError, TypeError) as exc:
        rec['error'] = {'category':'model_parse','type':type(exc).__name__,'message':str(exc)[:1000]}
    except Exception as exc:
        rec['error'] = {'category':'runtime_error','type':type(exc).__name__,'message':str(exc)[:1000]}
    rec.update(finished_at=c.now(),elapsed_s=time.monotonic()-start,
               logical_stages=len(rec['stages']),runtime_calls=sum(len(s['attempts']) for s in rec['stages']))
    return rec


def score(rec, sample):
    point = rec['prediction_px']; box=sample['bbox']
    rec['correctness'] = 'wrong_format' if rec['error'] else (
        'correct' if point is not None and box[0]<=point[0]<=box[2] and box[1]<=point[1]<=box[3] else 'wrong')
    rec.update(gt_bbox=box, instruction=sample['instruction'],group=sample['group'],
               ui_type=sample['ui_type'],application=sample.get('application'),img_size=sample['img_size'])
    return rec

