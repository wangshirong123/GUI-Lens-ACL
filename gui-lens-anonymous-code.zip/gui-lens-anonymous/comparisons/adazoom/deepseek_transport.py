"""Official DeepSeek transport; one HTTP attempt per invocation, no stored credentials."""
import base64, json, os, time
from pathlib import Path
import requests
API_CONFIG={'model':'deepseek-flash','base_url':'https://api.deepseek.com','thinking':{'type':'disabled'},'max_tokens':1024,'stream':False,'system':'You are a helpful assistant.','image_detail':'original','http_timeout_s':180}
RETRY_HTTP={408,429,500,502,503,504}
def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def key():
    secret=os.environ.get('DEEPSEEK_API_KEY','').strip()
    require(bool(secret),'Missing DEEPSEEK_API_KEY; use hidden-input launcher')
    return secret
def safe_error(message):
    secret=os.environ.get('DEEPSEEK_API_KEY','')
    return str(message).replace(secret,'[REDACTED]')[:2000] if secret else str(message)[:2000]
def payload(prompt,image):
    raw=Path(image).read_bytes();require(len(raw)<=32*2**20,'PNG exceeds inline image limit')
    return {'model':API_CONFIG['model'],'thinking':API_CONFIG['thinking'],'max_tokens':API_CONFIG['max_tokens'],'stream':False,
      'messages':[{'role':'system','content':API_CONFIG['system']},{'role':'user','content':[
       {'type':'text','text':prompt},{'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(raw).decode('ascii'),'detail':'original'}}]}]}
def metadata(out,c,baseline_identity):
    with requests.Session() as session:
        resp=session.get(API_CONFIG['base_url']+'/models',headers={'Authorization':'Bearer '+key()},timeout=(15,30),allow_redirects=False)
    require(resp.status_code==200,'Metadata HTTP '+str(resp.status_code))
    model=next((v for v in resp.json().get('data',[]) if v.get('id')==API_CONFIG['model']),None)
    require(model is not None,'Configured model missing')
    if 'input_modalities' in model:require('image' in model['input_modalities'],'Image modality missing')
    identity={k:model.get(k) for k in ('id','name','input_modalities')}
    require(identity==baseline_identity,'Model identity differs from completed DeepSeek baseline')
    path=out/'model_metadata.json'
    if path.exists():require(c.read(path)['identity']==identity,'Model identity changed on resume')
    else:c.save(path,{'identity':identity,'model':model,'time':c.now()})
def request_once(prompt,image):
    """Transport exceptions become explicit failures; an HTTP 200 body is never retried."""
    body=payload(prompt,image);secret=key();start=time.monotonic()
    result={'usage':None}
    try:
        with requests.Session() as session:
            resp=session.post(API_CONFIG['base_url']+'/chat/completions',headers={'Authorization':'Bearer '+secret,'Content-Type':'application/json'},json=body,timeout=(20,180),allow_redirects=False)
        result.update(http_status=resp.status_code,request_id=resp.headers.get('x-request-id'))
        if resp.status_code!=200:
            result['error']={'category':'provider_transport' if resp.status_code in RETRY_HTTP else 'provider_error','http_status':resp.status_code,'retryable':resp.status_code in RETRY_HTTP,'message':safe_error(resp.text)}
        else:
            result['response_text']=resp.text
            try:
                response=resp.json();result.update(response=response,usage=response.get('usage'),returned_model=response.get('model'))
            except (ValueError,TypeError):pass
    except requests.RequestException as exc:
        result['error']={'category':'provider_transport','retryable':True,'message':safe_error(exc)}
    result['elapsed_s']=time.monotonic()-start
    return result
