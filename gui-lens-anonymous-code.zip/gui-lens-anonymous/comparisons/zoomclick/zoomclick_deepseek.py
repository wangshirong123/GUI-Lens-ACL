"""Pinned official ZoomClick search, with checkpointed DeepSeek image API calls."""
import json,shutil,tempfile,time
from pathlib import Path
from PIL import Image
import psutil
import official_core as core
import experiment_io as c
import deepseek_transport as t
from json_parsing import parse_json
HERE=Path(__file__).resolve().parent
SEARCH=dict(max_search_depth=3,shrink_ratio=0.5,min_crop_size=768,patch_size=2,center_mode='clip',prezoom_px_thresh=50.0)
STAGES=tuple('call_%02d'%i for i in range(1,8))
PROMPT="You are a precise GUI grounding model. You are given a screenshot and an\ninstruction naming one UI target to click. Output the pixel coordinates of the\nCENTER of that target, in the ORIGINAL image coordinate system.\n\nImage size: width={w}, height={h} pixels. Coordinates must be integers with\n0 <= x < {w} and 0 <= y < {h}.\n\nInstruction: {instr}\n\nReply with ONLY JSON: {{\"x\": <int>, \"y\": <int>}}"
CONFIG={'method':'Official ZoomClick search with independent DeepSeek backend adaptation','model':'deepseek-flash','provider':'deepseek-official','upstream':core.PROVENANCE,'search':SEARCH,'prompt':PROMPT,'api':t.API_CONFIG,'normal_calls_per_sample':'5 to 7; official early stop','prompt_provenance':'Exact pixel-JSON prompt from completed pure DeepSeek baseline; model-specific Qwen/UI-Venus template replaced','image_processing':'Official RGB crops with no additional pixel upscaling. Original image detail; DeepSeek server preprocessing unchanged. Native crop sizes are included in prompt.','coordinate_contract':'Integer pixels of supplied view -> normalized point for unchanged official remapping/rounding/clip','format_policy':'Invalid coordinate response returns None to official fallbacks; report all format-failed calls separately, no answer-based retry','scoring':'Inclusive original-image point-in-box; all 1581 results in denominator','sampling':'temperature and top_p omitted, as pure DeepSeek; not claimed identical to upstream greedy decoding','context':'Only current image, instruction, dimensions. No GT, OCR, detector, prior predictions or history.'}
class StageFailure(Exception):
    def __init__(self,error):self.error=error;super().__init__(error.get('message',str(error)))
class ModelOutputError(ValueError):pass

def parse_point(raw,w,h):
    value=parse_json(raw)
    if not isinstance(value,dict) or not all(k in value for k in ('x','y')):raise ModelOutputError('Expected JSON x/y')
    x,y=value['x'],value['y']
    if type(x) is not int or type(y) is not int:raise ModelOutputError('Coordinates must be integers')
    if not 0<=x<w or not 0<=y<h:raise ModelOutputError('Coordinates out of supplied view bounds')
    return [x,y]

class DeepSeekBackend(core.BaseBackend):
    def __init__(self,folder,views):self.folder=Path(folder);self.views=Path(views);self.stages=[];self.formats=[];self.saved=[]
    def infer_norm_point(self,instruction,pil_img):
        number=len(self.stages)+1;c.require(number<=len(STAGES),'Unexpected official call count')
        name=STAGES[number-1];w,h=pil_img.size;prompt=PROMPT.format(w=w,h=h,instr=instruction)
        image=self.views/(name+'.png');pil_img.save(image,'PNG')
        info={'sha256':c.sha(image),'size':[w,h],'mode':pil_img.mode}
        fingerprint=c.digest({'stage':name,'prompt':prompt,'images':[info],'config':CONFIG})
        checkpoint=self.folder/(name+'.json')
        if checkpoint.exists():
            saved=c.read(checkpoint)
            c.require(saved['fingerprint']==fingerprint,'Stage inputs changed: '+name)
            c.require(saved['status']=='finished','Unknown inflight outcome; no replay: '+name)
        else:
            t.key();c.require(psutil.virtual_memory().available/2**30>=1.5 and shutil.disk_usage(self.folder).free/2**30>=2,'Insufficient resources before request')
            saved={'stage':name,'fingerprint':fingerprint,'prompt':prompt,'images':[info],'status':'inflight','attempts':[],'started_at':c.now()}
            c.save(checkpoint,saved)
            item={'attempt':1,'started_at':c.now(),**t.request_once(prompt,[image]),'finished_at':c.now()}
            saved.update(status='finished',finished_at=item['finished_at'],attempts=[item],error=item.get('error'))
            c.save(checkpoint,saved)
        self.stages.append({'stage':name,'record':checkpoint.name,'fingerprint':fingerprint});self.saved.append(saved)
        if saved.get('error'):raise StageFailure(saved['error'])
        item=saved['attempts'][0]
        c.require(item.get('http_status')==200 and item.get('returned_model')==CONFIG['model'],'Unexpected provider response/model; preserve without replay')
        try:choice=item['response']['choices'][0];raw=choice['message']['content']
        except (KeyError,IndexError,TypeError) as exc:raise RuntimeError('Malformed provider envelope; inspect saved response') from exc
        try:
            if choice.get('finish_reason')!='stop' or not isinstance(raw,str):raise ModelOutputError('Incomplete or nontext coordinate output')
            point=parse_point(raw,w,h)
        except (ValueError,TypeError,KeyError) as exc:
            self.formats.append({'stage':name,'message':str(exc)[:500]});return None,raw
        return (point[0]/w,point[1]/h),raw

def predict(public,folder):
    start=time.monotonic();rec={'sample_id':public['id'],'model':CONFIG['model'],'provider':CONFIG['provider'],'prediction_px':None,'error':None,'started_at':c.now()}
    backend=None;runner=None
    try:
        with tempfile.TemporaryDirectory(dir=folder,prefix='views_') as views:
            backend=DeepSeekBackend(folder,views);runner=core.PrezoomIterativeNarrowingRunner(backend,debug=False,**SEARCH)
            with Image.open(c.IMAGES/(public['id']+'.png')) as source:
                with source.convert('RGB') as img:result=runner.ground_only_positive(public['instruction'],img)
            rec['prediction_px']=result['point']
            if result['point'] is None:rec['error']={'category':'model_parse','message':'Official search returned no point'}
    except StageFailure as exc:rec['error']=exc.error
    except Exception as exc:rec['error']={'category':'runtime_error','type':type(exc).__name__,'message':t.safe_error(exc)}
    rec.update(stages=backend.stages if backend else [],search_log=runner.logs if runner else [],format_failure_calls=len(backend.formats) if backend else 0,format_failures=backend.formats if backend else [],finished_at=c.now(),elapsed_s=time.monotonic()-start)
    return rec

def score(rec,sample):
    p=rec['prediction_px'];b=sample['bbox']
    rec['correctness']='wrong_format' if rec['error'] else ('correct' if p is not None and b[0]<=p[0]<=b[2] and b[1]<=p[1]<=b[3] else 'wrong')
    rec.update(gt_bbox=b,instruction=sample['instruction'],group=sample['group'],ui_type=sample['ui_type'],img_size=sample['img_size'],application=sample.get('application'))
    return rec
