"""Load unchanged upstream geometry/algorithm definitions without local model imports."""
import ast
import hashlib
import json
import math
import os
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent / 'upstream'
PROVENANCE = json.loads((ROOT / 'provenance.json').read_text(encoding='utf-8'))
SOURCE = ROOT / 'grounding/eval_sspro_zoomclick.py'
NAMES = ['_clamp', '_norm_to_pixel_point', '_px_box_to_norm_box',
         'view_point_to_real_point', 'view_box_to_real_box', 'crop_center_px',
         'generate_patches', 'compute_pixel_distance', 'BaseBackend',
         'prezoom_first_iteration_distance', 'PrezoomIterativeNarrowingRunner']

def verify_sources():
    for name, expected in PROVENANCE['files'].items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
            raise RuntimeError('Pinned upstream source changed: ' + name)

verify_sources()
tree = ast.parse(SOURCE.read_text(encoding='utf-8'))
nodes = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in NAMES]
if [n.name for n in nodes] != NAMES:
    raise RuntimeError('Upstream core definition set changed')
# Exact AST bodies, including rounding, boundary handling and failure fallbacks.
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(SOURCE), 'exec'), globals())
