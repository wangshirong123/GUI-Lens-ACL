"""Same BAMI geometry/prompts as prior LUNA run, using DeepSeek for all six stages."""
import tempfile,time,shutil
import psutil
from dataclasses import asdict
from pathlib import Path
from PIL import Image
import bami_core as b
import experiment_io as c
import deepseek_transport as t
from json_parsing import parse_json
STAGES=tuple(f'r{r}_{s}' for r in (1,2) for s in ('candidate_1','candidate_2','judge'))
CONFIG={'method':'BAMI independent point-output adaptation','model':'deepseek-flash','provider':'deepseek-official','geometry':asdict(b.Config()),'ground_prompt':b.GROUND_PROMPT,'judge_prompt':b.JUDGE_PROMPT,'api':t.API_CONFIG,'logical_calls':6,'inter_round_crops':1,'scoring':'Inclusive original-image point-in-box; all 1581 samples including format failures stay in denominator','context':'All grounding and comparison stages use independent DeepSeek calls; no OCR, detector, label access or baseline-prediction reuse','image_storage':'Deterministic views are temporary; input-image hashes and all responses are permanent; no alteration of PNG pixels or image order','adaptation':'Reuses the previously evaluated independent BAMI interpretation and parameters; replaces both grounder and judge with DeepSeek; not an official trained-system reproduction'}
class StageFailure(Exception):
    def __init__(self,error):self.error=error;super().__init__(error.get('message',str(error)))
class ModelOutputError(Exception):pass

def stage(name,prompt,images,folder,rec):
    c.require(name in STAGES,'Unexpected stage')
    info=[]
    for p in images:
        with Image.open(p) as im:size=list(im.size)
        info.append({'sha256':c.sha(p),'size':size})
    fingerprint=c.digest({'stage':name,'prompt':prompt,'images':info,'config':CONFIG})
    checkpoint=folder/(name+'.json')
    if checkpoint.exists():
        saved=c.read(checkpoint)
        c.require(saved['fingerprint']==fingerprint,'Stage input changed on resume: '+name)
        c.require(saved['status']=='finished','Unknown inflight result; replay prohibited: '+name)
    else:
        t.key()
        c.require(psutil.virtual_memory().available/2**30>=1.5 and shutil.disk_usage(folder).free/2**30>=2,'Insufficient RAM or disk before API request')
        saved={'stage':name,'fingerprint':fingerprint,'prompt':prompt,'images':info,'status':'inflight','attempts':[],'started_at':c.now()}
        c.save(checkpoint,saved)
        item={'attempt':1,'started_at':c.now(),**t.request_once(prompt,images),'finished_at':c.now()}
        saved.update(status='finished',finished_at=item['finished_at'],attempts=[item],error=item.get('error'))
        c.save(checkpoint,saved)
    # Result contains references instead of duplicating long raw responses.
    rec['stages'].append({'stage':name,'record':checkpoint.name,'fingerprint':fingerprint})
    if saved.get('error'):raise StageFailure(saved['error'])
    item=saved['attempts'][0]
    c.require(item.get('returned_model')==t.API_CONFIG['model'],'Unexpected/missing returned model; do not replay response')
    try:
        choice=item['response']['choices'][0]
        if choice.get('finish_reason')!='stop':raise ModelOutputError('Incomplete model output: '+str(choice.get('finish_reason')))
        raw=choice['message']['content']
        if not isinstance(raw,str):raise ModelOutputError('No text model output')
        value=parse_json(raw)
        if not isinstance(value,dict):raise ModelOutputError('Expected a JSON object')
        try:
            if name.endswith('_judge'):b.choice_from(value)
            else:b.point_from(value,info[0]['size'])
        except (ValueError,KeyError,TypeError) as exc:raise ModelOutputError(str(exc)) from exc
        return value
    except (KeyError,IndexError,TypeError) as exc:raise RuntimeError('Malformed provider response; saved response must be inspected') from exc
    except ValueError as exc:raise ModelOutputError(str(exc)) from exc

def predict(public,folder):
    # Only ID, instruction and dimensions enter inference; scoring is separate.
    sid=public['id'];start=time.monotonic()
    rec={'sample_id':sid,'model':CONFIG['model'],'provider':CONFIG['provider'],'prediction_px':None,'stages':[],'error':None,'started_at':c.now()}
    try:
        # Only generated views in this newly-created temporary directory are removed.
        # Checkpoints are in folder, and survive failures and resume.
        with tempfile.TemporaryDirectory(dir=folder,prefix='views_') as views:
            result=b.predict(c.IMAGES/(sid+'.png'),public['instruction'],Path(views),lambda n,p,ims:stage(n,p,ims,folder,rec))
        rec.update(result)
    except StageFailure as exc:rec['error']=exc.error
    except ModelOutputError as exc:rec['error']={'category':'model_parse','type':type(exc).__name__,'message':t.safe_error(exc)}
    except Exception as exc:rec['error']={'category':'runtime_error','type':type(exc).__name__,'message':t.safe_error(exc)}
    rec.update(finished_at=c.now(),elapsed_s=time.monotonic()-start)
    return rec

def score(rec,sample):
    p=rec['prediction_px'];b=sample['bbox']
    rec['correctness']='wrong_format' if rec['error'] else ('correct' if p is not None and b[0]<=p[0]<=b[2] and b[1]<=p[1]<=b[3] else 'wrong')
    rec.update(gt_bbox=b,instruction=sample['instruction'],group=sample['group'],ui_type=sample['ui_type'],img_size=sample['img_size'],application=sample.get('application'))
    return rec
