"""DeepSeek official single/multi-image transport. Credentials are never persisted."""
import base64,os,time
from pathlib import Path
import requests
API_CONFIG={'model':'deepseek-flash','base_url':'https://api.deepseek.com','thinking':{'type':'disabled'},'max_tokens':1024,'stream':False,'system':'You are a helpful assistant.','image_detail':'original','http_timeout_s':180}
RETRY_HTTP={408,429,500,502,503,504}
def require(ok,message):
    if not ok:raise RuntimeError(message)
def validate_key(secret):
    require(bool(secret) and all(33<=ord(x)<=126 for x in secret) and not any(x in secret for x in ('"',"'")),'Invalid API key: paste only ASCII key characters without spaces or quotation marks; value not logged')
def key():
    value=os.environ.get('DEEPSEEK_API_KEY','').strip();validate_key(value);return value
def safe_error(value):
    secret=os.environ.get('DEEPSEEK_API_KEY','')
    return (str(value).replace(secret,'[REDACTED]') if secret else str(value))[:2000]
def payload(prompt,images):
    require(isinstance(images,(list,tuple)) and 1<=len(images)<=2,'Expected one grounding image or two comparison images')
    content=[{'type':'text','text':prompt}]
    for image in images:
        raw=Path(image).read_bytes();require(len(raw)<=32*2**20,'PNG exceeds inline image limit')
        content.append({'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(raw).decode('ascii'),'detail':'original'}})
    return {'model':API_CONFIG['model'],'thinking':API_CONFIG['thinking'],'max_tokens':API_CONFIG['max_tokens'],'stream':False,'messages':[{'role':'system','content':API_CONFIG['system']},{'role':'user','content':content}]}
def metadata(out,c,expected):
    with requests.Session() as session:
        response=session.get(API_CONFIG['base_url']+'/models',headers={'Authorization':'Bearer '+key()},timeout=(15,30),allow_redirects=False)
    require(response.status_code==200,'Model metadata HTTP '+str(response.status_code))
    model=next((x for x in response.json().get('data',[]) if x.get('id')==API_CONFIG['model']),None)
    require(model is not None,'Configured model missing from provider metadata')
    identity={k:model.get(k) for k in ('id','name','input_modalities')}
    require(identity==expected,'Model identity differs from completed DeepSeek baselines')
    require('image' in (identity.get('input_modalities') or []),'Image support not advertised')
    path=out/'model_metadata.json'
    if path.exists():require(c.read(path)['identity']==identity,'Model identity changed on resume')
    else:c.save(path,{'identity':identity,'model':model,'time':c.now()})
def request_once(prompt,images):
    body=payload(prompt,images);secret=key();start=time.monotonic();item={'usage':None}
    try:
        with requests.Session() as session:
            resp=session.post(API_CONFIG['base_url']+'/chat/completions',headers={'Authorization':'Bearer '+secret,'Content-Type':'application/json'},json=body,timeout=(20,180),allow_redirects=False)
        item.update(http_status=resp.status_code,request_id=resp.headers.get('x-request-id'),response_text=safe_error(resp.text) if resp.status_code!=200 else resp.text)
        try:
            response=resp.json()
            if isinstance(response,dict):item.update(response=response,usage=response.get('usage'),returned_model=response.get('model'))
        except (ValueError,TypeError):pass
        if resp.status_code!=200:
            item['error']={'category':'provider_transport' if resp.status_code in RETRY_HTTP else 'provider_error','retryable':resp.status_code in RETRY_HTTP,'outcome_unknown':False,'http_status':resp.status_code,'message':safe_error(resp.text)}
    except requests.ConnectTimeout as exc:
        item['error']={'category':'provider_transport','retryable':True,'outcome_unknown':False,'message':safe_error(exc)}
    except requests.RequestException as exc:
        # Read timeout/disconnection may follow a billed response: never auto-replay.
        item['error']={'category':'provider_transport','retryable':False,'outcome_unknown':True,'message':safe_error(exc)}
    item['elapsed_s']=time.monotonic()-start
    return item
