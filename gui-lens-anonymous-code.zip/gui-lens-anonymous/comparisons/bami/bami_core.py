"""Independent BAMI point-output adaptation; no dataset labels or provider state."""
import hashlib
import json
import math
import random
from dataclasses import asdict, dataclass
from pathlib import Path

from PIL import Image, ImageDraw

GROUND_PROMPT = '''You are a precise GUI grounding model. You are given a screenshot and an
instruction naming one UI target to click. Output the pixel coordinates of the
CENTER of that target, in the ORIGINAL image coordinate system.

Image size: width={w}, height={h} pixels. Coordinates must be integers with
0 <= x < {w} and 0 <= y < {h}.

Instruction: {instr}

Reply with ONLY JSON: {{"x": <int>, "y": <int>}}'''

# Independent wording implementing Appendix C.1's comparison principles.
JUDGE_PROMPT = '''Compare two proposed GUI targets for this instruction: {instr}
Both images show the same unmasked screenshot. Image 1 outlines candidate 1
in green; image 2 outlines candidate 2 in red. These outlines are annotations,
not interface state. Decide which outlined target better satisfies the instruction.
Describe each outlined control and compare their functions using visible evidence,
standard GUI patterns, and the user's actual goal, rather than keyword overlap.
Consider what each target does and its surrounding interface context. Prefer an
actionable control to a decorative or noninteractive element. Where appropriate,
prefer a normal control over one already selected. When semantics are otherwise
comparable, prefer icon with text, then a complete icon, then complete text,
then a box containing multiple or incomplete elements, in that order.
Explain the comparison briefly, then choose exactly one of the supplied candidates.
Return ONLY JSON: {{"analysis": "brief comparison", "choice": 1 or 2}}.'''


@dataclass(frozen=True)
class Config:
    rounds: int = 2
    candidates: int = 2
    crop_ratio: float = 0.6
    point_radius: int = 25
    mask_seed: int = 20261009
    mask_fill: str = 'seeded_rgb_noise'
    resize: str = 'lanczos_to_initial_size'

    def __post_init__(self):
        if self.rounds < 1 or self.candidates != 2:
            raise ValueError('This audited adapter supports two candidates per round')
        if not 0 < self.crop_ratio < 1 or self.point_radius < 1:
            raise ValueError('Invalid crop ratio or radius')
        if self.mask_fill != 'seeded_rgb_noise' or self.resize != 'lanczos_to_initial_size':
            raise ValueError('Unsupported image protocol')


def json_object(raw):
    if isinstance(raw, dict):
        return raw
    if not isinstance(raw, str):
        raise ValueError('Expected JSON object')
    text = raw.strip()
    if text.startswith('```') and text.endswith('```'):
        text = text.split('\n', 1)[1].rsplit('```', 1)[0].strip()
    value = json.loads(text)
    if not isinstance(value, dict):
        raise ValueError('Expected JSON object')
    return value


def point_from(raw, size):
    value = json_object(raw)
    point = []
    for key, bound in zip(('x', 'y'), size):
        x = value[key]
        if isinstance(x, str) and x.strip().lstrip('-').isdigit():
            x = int(x)
        if isinstance(x, float) and x.is_integer():
            x = int(x)
        if type(x) is not int or not 0 <= x < bound:
            raise ValueError('Invalid coordinate ' + key)
        point.append(x)
    return tuple(point)


def choice_from(raw):
    value = json_object(raw)
    choice = value.get('choice')
    if type(choice) is not int or choice not in (1, 2):
        raise ValueError('Judge must choose candidate 1 or 2; no fallback')
    return choice - 1


def candidate_box(point, size, radius):
    x, y = point
    w, h = size
    # Half-open box: exactly 50 x 50 pixels away from image boundaries.
    return max(0, x-radius), max(0, y-radius), min(w, x+radius), min(h, y+radius)


def masked_image(clean, boxes, seed):
    image = clean.copy()
    rng = random.Random(seed)
    for l, t, r, b in boxes:
        patch = Image.frombytes('RGB', (r-l, b-t), rng.randbytes((r-l)*(b-t)*3))
        image.paste(patch, (l, t))
        patch.close()
    return image


def marked_image(clean, box, color, label):
    image = clean.copy()
    l, t, r, b = box
    draw = ImageDraw.Draw(image)
    draw.rectangle((l, t, r-1, b-1), outline=color, width=2)
    # Keep the label close to the outline; avoid covering its center where possible.
    tx, ty = min(l, max(0, image.width-10)), max(0, t-13)
    draw.rectangle((tx, ty, tx+9, ty+11), fill=color)
    draw.text((tx+2, ty), str(label), fill='black')
    return image


def crop_bounds(size, point, ratio):
    w, h = size
    cw, ch = max(1, math.floor(w*ratio)), max(1, math.floor(h*ratio))
    l = min(max(0, math.floor(point[0]-cw/2)), w-cw)
    t = min(max(0, math.floor(point[1]-ch/2)), h-ch)
    return l, t, l+cw, t+ch


@dataclass(frozen=True)
class Transform:
    x0: float = 0.0
    y0: float = 0.0
    sx: float = 1.0
    sy: float = 1.0

    def map(self, point):
        return (self.x0 + point[0]*self.sx, self.y0 + point[1]*self.sy)

    def cropped(self, bounds, output_size):
        l, t, r, b = bounds
        return Transform(self.x0+l*self.sx, self.y0+t*self.sy,
                         self.sx*(r-l)/output_size[0], self.sy*(b-t)/output_size[1])


def predict(image_path, instruction, output_dir, backend, config=Config()):
    """backend(stage, prompt, image_paths) -> raw response; it owns checkpointing.

    Only screenshot and instruction enter this function. Ground truth must be
    handled by a separate scorer after this function returns.
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    with Image.open(image_path) as source:
        clean = source.convert('RGB')
    initial_size = clean.size
    transform = Transform()
    rounds = []
    final_point = None
    try:
        for round_index in range(config.rounds):
            prefix = f'r{round_index+1}'
            clean_path = out / f'{prefix}_clean.png'
            clean.save(clean_path)
            points, boxes = [], []
            prompt = GROUND_PROMPT.format(w=clean.width, h=clean.height, instr=instruction)
            seed = int(hashlib.sha256((str(config.mask_seed)+instruction+prefix).encode()).hexdigest()[:16], 16)
            for i in range(config.candidates):
                path = clean_path
                if i:
                    path = out / f'{prefix}_masked_{i+1}.png'
                    with masked_image(clean, boxes, seed) as masked:
                        masked.save(path)
                raw = backend(f'{prefix}_candidate_{i+1}', prompt, [path])
                point = point_from(raw, clean.size)
                points.append(point)
                boxes.append(candidate_box(point, clean.size, config.point_radius))
            marked_paths = []
            for i, (box, color) in enumerate(zip(boxes, ('#00ff00', '#ff0000'))):
                path = out / f'{prefix}_judge_{i+1}.png'
                with marked_image(clean, box, color, i+1) as marked:
                    marked.save(path)
                marked_paths.append(path)
            choice = choice_from(backend(f'{prefix}_judge', JUDGE_PROMPT.format(instr=instruction), marked_paths))
            final_point = transform.map(points[choice])
            record = dict(round=round_index+1, size=list(clean.size), candidates=points,
                          boxes=boxes, selected=choice+1, duplicate_candidates=points[0]==points[1],
                          transform=asdict(transform), original_point=final_point)
            rounds.append(record)
            if round_index+1 < config.rounds:
                bounds = crop_bounds(clean.size, points[choice], config.crop_ratio)
                record['next_crop'] = bounds
                with clean.crop(bounds) as crop:
                    next_view = crop.resize(initial_size, Image.Resampling.LANCZOS)
                clean.close()
                clean = next_view
                transform = transform.cropped(bounds, initial_size)
        # Retain the model point, not the center of a boundary-clipped mask box.
        return dict(prediction_px=final_point, original_size=initial_size, rounds=rounds,
                    logical_calls=config.rounds*(config.candidates+1), config=asdict(config))
    finally:
        clean.close()
