"""Original direct-grounding prompt and parser, extracted without behavior changes."""

import json

from json_parsing import parse_json

PROMPT = '''You are a precise GUI grounding model. You are given a screenshot and an
instruction naming one UI target to click. Output the pixel coordinates of the
CENTER of that target, in the ORIGINAL image coordinate system.

Image size: width={w}, height={h} pixels. Coordinates must be integers with
0 <= x < {w} and 0 <= y < {h}.

Instruction: {instr}

Reply with ONLY JSON: {{"x": <int>, "y": <int>}}'''

def parse_point(raw, width, height):
    from json_parsing import parse_json
    value = parse_json(raw)
    point = []
    for key in ['x', 'y']:
        x = value[key]
        if isinstance(x, bool): raise ValueError('Boolean coordinate')
        if isinstance(x, str):
            if not x.strip().lstrip('-').isdigit(): raise ValueError('Noninteger coordinate')
            x = int(x)
        if isinstance(x, float) and x.is_integer(): x = int(x)
        if not isinstance(x, int): raise ValueError('Noninteger coordinate')
        point.append(x)
    if not (0 <= point[0] < width and 0 <= point[1] < height):
        raise ValueError('Coordinate outside original image')
    return point

def correct(point, bbox):
    return bbox[0] <= point[0] <= bbox[2] and bbox[1] <= point[1] <= bbox[3]
