"""Portable direct baseline; original prompt/parser and HTTP payload are retained."""
import time
import direct_core as core
import experiment_io as c
import deepseek_transport as t
CONFIG={"method":"Direct full-image point prediction","api":t.API_CONFIG,"prompt":core.PROMPT}
def predict(public,folder):
    w,h=public["img_size"];image=c.IMAGES/(public["id"]+".png")
    prompt=core.PROMPT.format(w=w,h=h,instr=public["instruction"])
    fingerprint=c.digest({"prompt":prompt,"image_sha256":c.sha(image),"config":CONFIG})
    checkpoint=folder/"ground.json"
    rec={"sample_id":public["id"],"model":"deepseek-flash","prediction_px":None,"error":None}
    if checkpoint.exists():
        saved=c.read(checkpoint)
        c.require(saved["fingerprint"]==fingerprint,"Stage input changed")
        c.require(saved["status"]=="finished","Unknown inflight outcome; no replay")
    else:
        t.key();saved={"stage":"ground","fingerprint":fingerprint,"status":"inflight","attempts":[],"started_at":c.now()}
        c.save(checkpoint,saved)
        item={**t.request_once(prompt,image),"finished_at":c.now()}
        saved.update(status="finished",attempts=[item],error=item.get("error"),finished_at=item["finished_at"])
        c.save(checkpoint,saved)
    item=saved["attempts"][0]
    if saved.get("error"):rec["error"]=saved["error"];return rec
    try:
        choice=item["response"]["choices"][0]
        if choice.get("finish_reason")!="stop":raise ValueError("Incomplete response")
        raw=choice["message"]["content"]
        if not isinstance(raw,str):raise ValueError("No text answer")
        rec["prediction_px"]=core.parse_point(raw,w,h)
    except (ValueError,KeyError,TypeError,IndexError) as exc:
        rec["error"]={"category":"model_parse","message":str(exc)}
    return rec
def score(rec,sample):
    rec["correctness"]="wrong_format" if rec["error"] else ("correct" if core.correct(rec["prediction_px"],sample["bbox"]) else "wrong")
    rec.update(gt_bbox=sample["bbox"],group=sample["group"],ui_type=sample["ui_type"],img_size=sample["img_size"])
    return rec
