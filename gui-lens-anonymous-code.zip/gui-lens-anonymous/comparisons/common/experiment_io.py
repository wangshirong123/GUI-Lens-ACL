"""Portable experiment storage. No account files are read."""
import hashlib,json,os,time,uuid
from pathlib import Path
from datetime import datetime
HERE=Path(os.environ.get("GUI_LENS_OUTPUT_DIR","runs/baseline")).resolve()
IMAGES=Path(os.environ.get("GUI_LENS_DATA_DIR","data/ScreenSpot-Pro")).resolve()/"images"
ANNOTATION=IMAGES.parent/"annotations"/"all.json"
REPO=Path(__file__).resolve().parents[2]
GROUPS=['CAD','Creative','Dev','Office','OS','Scientific']
def require(ok,message):
    if not ok:raise RuntimeError(message)
def now():return datetime.now().astimezone().isoformat()
def read(path):return json.loads(Path(path).read_text(encoding="utf-8-sig"))
def sha(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda:f.read(1024*1024),b""):h.update(block)
    return h.hexdigest()
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def save(path,value):
    path=Path(path).resolve()
    require(path.is_relative_to(HERE),"Output outside configured experiment")
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+"."+uuid.uuid4().hex+".tmp")
    with tmp.open("w",encoding="utf-8") as f:
        json.dump(value,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
    for n in range(21):
        try:os.replace(tmp,path);return
        except PermissionError:
            if n==20:raise
            time.sleep(.1)
def samples():return read(ANNOTATION)
