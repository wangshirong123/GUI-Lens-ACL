# Third-party notices

- GUI-Lens/GUI harness retains the included MIT LICENSE.
- Bundled OpenProgram 0.5.0 retains vendor/OpenProgram/LICENSE (AGPL-3.0-or-later).
  Identifying package metadata, repository links and account/network examples
  were modified for this review distribution. Full bundled runtime source is
  supplied. License texts and required legal notices are retained.
- ZoomClick is an external dependency at
  https://github.com/Princeton-AI2-Lab/ZoomClick,
  commit 6a0c3633eb6985a21d99c94400bc64fe54ac5221.
  Upstream source is not redistributed in this archive. A retrieval script verifies
  six hashes. Consult upstream terms before redistributing it.
- AdaZoom-GUI and BAMI comparisons are independent adaptations, not redistributed
  trained systems. See comparisons/README.md for protocol differences.
- ScreenSpot-Pro, UI-Vision, MMBench-GUI, OSWorld, GPA-GUI-Detector and EasyOCR are
  external assets/software/data. Obtain them under their own terms and retain
  appropriate citations. Their original assets are not bundled.
- Removing submitting-author metadata is separate from retaining third-party
  copyright notices and attribution.
