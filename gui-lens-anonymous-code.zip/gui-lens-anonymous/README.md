# GUI-Lens: anonymous review code

Code for **GUI-Lens: Coarse-to-Fine Cropping for GUI Grounding with General-Purpose VLMs**.

## Start here

- Main grounding method: gui_harness/planning/screenspot_locator.py.
- OCR/detector coordinate references: gui_harness/perception/.
- Main evaluator: benchmarks/screenspot_pro/run_screenspot_pro.py.
- Explicit model/config launcher: run_guilens.py.
- DeepSeek comparisons: run_baseline.py and comparisons/.
- Offline result/table audit: tools/report_results.py.
- Reproduction details: REPRODUCIBILITY.md.
- Adaptation details: comparisons/README.md.
- Licenses: THIRD_PARTY_NOTICES.md.

## Quick offline check

Use Python 3.11:

    python -m pip install -r environment/requirements-baselines.txt
    python tools/report_results.py
    python -m unittest discover -s tests -p "test_review_package.py"

These commands use exported predictions and synthetic images; they do not contact a model.
The ZoomClick checkpoint test is exercised after fetching its pinned external source.
No API keys, account files, local experiment paths, Git history, raw provider responses,
user screenshots or model weights are bundled.

## Completed same-backbone ScreenSpot-Pro comparisons

All rows contain 1,581 unique examples. Format failures remain in the denominator.

| Method | Model | Correct | Incorrect | Final format errors | Final runtime errors | Accuracy |
|---|---|---:|---:|---:|---:|---:|
| Direct prediction | DeepSeek-V4.1-Flash | 45 | 1525 | 11 | 0 | 2.85% |
| AdaZoom-GUI adaptation | DeepSeek-V4.1-Flash | 321 | 1249 | 11 | 0 | 20.30% |
| BAMI adaptation | DeepSeek-V4.1-Flash | 195 | 1318 | 68 | 0 | 12.33% |
| ZoomClick adaptation | DeepSeek-V4.1-Flash | 399 | 1182 | 0 | 0 | 25.24% |

API model ID: deepseek-flash; recorded metadata name: DeepSeek-V4.1-Flash.
A provider alias can change. ZoomClick stage format failures can trigger its
official fallback and are distinct from final sample format errors.

Results preserve predictions, scoring labels, grouping and numeric usage.
Production request IDs, raw responses, machine paths, PIDs and wall-clock timestamps
are excluded. Missing provider usage is **unknown**, not zero. A complete monetary
cost is not asserted.

## Run a comparison

Prepare the official dataset as described in REPRODUCIBILITY.md.
For ZoomClick first fetch its pinned source:

    python tools/fetch_zoomclick.py
    python run_baseline.py --method zoomclick --data-dir data/ScreenSpot-Pro --check
    python run_baseline.py --method zoomclick --data-dir data/ScreenSpot-Pro --output-dir runs/zoomclick --run --workers 4 --prompt-key --retry-network

Methods: direct, adazoom, bami, zoomclick. The hidden prompt reads a key into the
current process only. Alternatively set DEEPSEEK_API_KEY in your own environment.
Actual inference uses a paid external API; provider sampling and preprocessing
mean a rerun is not guaranteed bitwise identical.

Existing outputs require --resume. Successful checkpoints and predictions are reused.
Finished transport failures are deferred. --retry-network authorizes at most two
recoveries/sample and twenty/run with 60-second cooldown. Unknown inflight requests
are not replayed. Authentication, balance, resource, STOP and integrity errors stop
execution. Private historical recovery plans are not imported or reset.

## Scope

Original algorithm cores and prompt strings are retained. Portable paths, storage
wrappers, launchers and offline checks were added for release. Packaging did not
perform new paid model calls. Multiple main-method configurations are included;
their presence does not establish that every paper row used the same setting.
See the explicit coverage notes in REPRODUCIBILITY.md.

## AI assistance disclosure

AI coding assistance was used in experiment implementation and to organize this
review artifact, remove identifying deployment information, write portable
launchers and create offline checks. The authors remain responsible for checking
the methods, provenance and reported results.
