import importlib,json,os,subprocess,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class ReviewPackageTests(unittest.TestCase):
    def script(self,code,*args):
        p=subprocess.run([sys.executable,"-X","utf8","-B","-c",code,str(ROOT),*args],capture_output=True,text=True,encoding="utf-8")
        self.assertEqual(p.returncode,0,p.stdout+p.stderr)
    def test_results_and_accounting(self):
        p=subprocess.run([sys.executable,"-X","utf8","-B",str(ROOT/"tools/report_results.py")],capture_output=True,text=True,encoding="utf-8")
        self.assertEqual(p.returncode,0,p.stderr)
    def test_direct_coordinate_contract(self):
        self.script("""import sys
from pathlib import Path
r=Path(sys.argv[1]);sys.path[:0]=[str(r/'comparisons/direct'),str(r/'comparisons/common')]
import direct_core as c
assert c.parse_point('{"x":"2","y":3.0}',10,10)==[2,3]
for x in ['true','1.5','10']:
 try:c.parse_point('{"x":'+x+',"y":3}',10,10)
 except ValueError:pass
 else:raise AssertionError(x)
assert c.correct([1,2],[1,2,4,5])
""")
    def test_bami_two_round_transform(self):
        self.script("""import sys,tempfile
from pathlib import Path
r=Path(sys.argv[1]);sys.path.insert(0,str(r/'comparisons/bami'))
import bami_core as b
from PIL import Image
with tempfile.TemporaryDirectory() as d:
 p=Path(d);Image.new('RGB',(100,80),'white').save(p/'in.png');calls=[]
 def backend(name,prompt,images):
  calls.append((name,len(images)))
  return {'choice':1} if name.endswith('judge') else {'x':50,'y':40}
 out=b.predict(p/'in.png','click test',p/'views',backend)
 assert out['prediction_px']==(50.0,40.0)
 assert len(calls)==6 and [n for n,count in calls]==['r1_candidate_1','r1_candidate_2','r1_judge','r2_candidate_1','r2_candidate_2','r2_judge']
 assert [c for n,c in calls]==[1,1,2,1,1,2]
""")
    def test_adazoom_gate_and_boundary_mapping(self):
        self.script("""import sys
from pathlib import Path
r=Path(sys.argv[1]);sys.path[:0]=[str(r/'comparisons/adazoom'),str(r/'comparisons/common')]
import adazoom_core as a
assert a.needs_zoom([0,0,50,100])
assert not a.needs_zoom([0,0,51,101])
assert a.crop_bounds([0,0],[100,80])==[0,0,50,40]
assert a.map_point([50,40],[25,20,75,60],[100,80])==[50.,40.]
""")
    def test_successful_stages_are_reused(self):
        for method in ("direct","adazoom","bami","zoomclick"):
            if method=="zoomclick" and not (ROOT/"comparisons/zoomclick/upstream/grounding/eval_sspro_zoomclick.py").exists():continue
            self.script("""import sys,tempfile,os,json
from pathlib import Path
r=Path(sys.argv[1]);method=sys.argv[2]
with tempfile.TemporaryDirectory() as d:
 p=Path(d);(p/'images').mkdir();(p/'out').mkdir();os.environ['GUI_LENS_DATA_DIR']=str(p);os.environ['GUI_LENS_OUTPUT_DIR']=str(p/'out')
 sys.path.insert(0,str(r));import run_baseline as runner;m=runner.load_method(method)
 from PIL import Image
 Image.new('RGB',(100,80),'white').save(p/'images/s.png')
 import deepseek_transport as t
 counter=[]
 t.key=lambda:'offline-test-only'
 def request(prompt,images):
  counter.append(prompt)
  if 'Rewrite the task' in prompt:content='click test'
  elif 'Compare two proposed' in prompt:content='{"choice":1}'
  elif '"bbox"' in prompt:content='{"x":50,"y":40,"bbox":[0,0,100,80]}'
  else:content='{"x":50,"y":40}'
  return {'http_status':200,'returned_model':'deepseek-flash','usage':{'prompt_tokens':1,'completion_tokens':1},'response':{'choices':[{'finish_reason':'stop','message':{'content':content}}]}}
 t.request_once=request
 sample={'id':'s','instruction':'click test','img_size':[100,80]};folder=p/'out/s';folder.mkdir()
 first=m.predict(sample,folder);n=len(counter)
 assert n>0 and first['error'] is None,first
 second=m.predict(sample,folder)
 assert len(counter)==n and second['prediction_px']==first['prediction_px']
""",method)
    def test_inflight_never_eligible_for_replay(self):
        self.script("""import sys,tempfile,json
from pathlib import Path
r=Path(sys.argv[1]);sys.path.insert(0,str(r));from run_baseline import finished_network
with tempfile.TemporaryDirectory() as d:
 p=Path(d);f=p/'call_01.json'
 f.write_text(json.dumps({'status':'inflight','error':{'category':'provider_transport'}}))
 assert finished_network(p)==[]
 f.write_text(json.dumps({'status':'finished','error':{'category':'provider_transport'},'attempts':[{'http_status':200}]}))
 assert finished_network(p)==[]
 f.write_text(json.dumps({'status':'finished','error':{'category':'provider_transport'},'attempts':[{'usage':None}]}))
 assert finished_network(p)==[f]
""")
    def test_global_failure_stops_dispatch(self):
        self.script("""import sys
from pathlib import Path
from types import SimpleNamespace
r=Path(sys.argv[1]);sys.path.insert(0,str(r));from run_baseline import run_phase
calls=[]
def fail(args,sample):
 calls.append(sample);raise RuntimeError('authentication failure')
try:run_phase(SimpleNamespace(workers=1),list(range(10)),fail)
except RuntimeError:pass
else:raise AssertionError('Global failure was suppressed')
assert calls==[0],calls
""")
    def test_network_failure_defers_and_continues(self):
        self.script("""import sys
from pathlib import Path
from types import SimpleNamespace
r=Path(sys.argv[1]);sys.path.insert(0,str(r));from run_baseline import run_phase
calls=[]
def outcome(args,sample):
 calls.append(sample);return sample!=1
assert run_phase(SimpleNamespace(workers=1),list(range(4)),outcome)==[1]
assert calls==[0,1,2,3]
""")
if __name__=="__main__":unittest.main()
